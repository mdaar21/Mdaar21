"""Original 150-bpm score and paper transition effects, synthesized without external samples."""
from pathlib import Path
import numpy as np,wave,json
sr=48000;duration=22.4
mix=np.zeros((round(sr*duration),2),dtype=np.float64);rng=np.random.default_rng(22500)
def put(sound,start,gain=.25,pan=0):
 start=round(start*sr);sound=np.asarray(sound);n=min(len(sound),len(mix)-start)
 if n<=0:return
 gains=np.array([np.sqrt((1-pan)/2),np.sqrt((1+pan)/2)])
 mix[start:start+n]+=sound[:n,None]*gain*gains
def pluck(freq,dur=.5,decay=8):
 t=np.arange(round(sr*dur))/sr;env=(1-np.exp(-130*t))*np.exp(-decay*t)
 return (np.sin(2*np.pi*freq*t)+.20*np.sin(2*np.pi*freq*2*t)+.10*np.sin(2*np.pi*freq*3*t))*env
def kick(start,amp=.34):
 t=np.arange(round(sr*.28))/sr;phase=2*np.pi*(49*t+72*.024*(1-np.exp(-t/.024)))
 put(np.sin(phase)*np.exp(-t*17),start,amp)
def tick(start,amp=.03,pan=.2):
 t=np.arange(round(sr*.055))/sr;n=rng.standard_normal(len(t));n[1:]-=.88*n[:-1]
 put(n*np.exp(-t*95),start,amp,pan)
def clap(start,amp=.08):
 t=np.arange(round(sr*.14))/sr;n=rng.standard_normal(len(t));n[1:]-=.55*n[:-1]
 env=np.exp(-t*35)*(1+.2*np.sin(2*np.pi*75*t));put(n*env,start,amp,-.1)
def chord(start,dur,frequencies,gain=.1):
 t=np.arange(round(sr*dur))/sr;env=np.minimum(t/.08,1)*np.minimum((dur-t)/.28,1)
 out=sum(np.sin(2*np.pi*f*t)+.12*np.sin(2*np.pi*f*2*t) for f in frequencies)/len(frequencies)
 put(out*env,start,gain)
def paper(start):
 t=np.arange(round(sr*.28))/sr;n=rng.standard_normal(len(t));n[1:]-=.68*n[:-1]
 flutter=(.6+.4*np.sin(2*np.pi*(40*t+70*t*t))**2)*np.sin(np.pi*t/.28)**2
 put(n*flutter,start,.055,-.1);put(pluck(98,.24,16),start+.09,.10)
# A light, confident rhythmic hook. A short break makes the question land.
roots=[73.416,58.270,87.307,65.406]
melody=[293.66,349.23,440,392,349.23,523.25,440,349.23]
for j in range(56):
 start=j*.4
 if 2.25<start<2.8:continue
 root=73.416 if start>=19.2 else roots[(j//4)%4];energy=.65 if start>=19.2 else (.8 if start<4.8 else 1)
 if j%2==0:kick(start+.018,.34*energy)
 if j%4 in [1,3]:clap(start+.018,.075*energy)
 tick(start+.20,.019*energy,.25 if j%2 else -.25)
 put(pluck(root,.33,11),start+.025,.15*energy)
 if j%2 or start>=4.8:put(pluck(melody[j%8],.42,9),start+.2,.075*energy,.18 if j%2 else -.18)
 if j%4==0:chord(start,1.55,[root*2,root*2*1.1892,root*3],.075)
for start in [2.22,4.62,7.82,11.02,13.42,16.62,19.02]:paper(start)
for start,freq in [(4.96,440),(5.12,587.33),(8.12,523.25),(8.28,659.25),(13.76,587.33),(13.92,880)]:
 put(pluck(freq,.42,10),start,.12,.1)
# The ending holds long enough to read the store address.
chord(19.22,3.15,[146.83,174.61,220,293.66],.14)
for t,f in [(19.28,587.33),(19.65,698.46),(20.02,880)]:put(pluck(f,1.1,4),t,.07)
t=np.arange(len(mix))/sr
mix*=np.minimum(t/.015,1)[:,None];mix*=np.minimum((duration-t)/.18,1)[:,None]
mix=np.tanh(mix*1.1);mix*=.82/max(np.max(np.abs(mix)),1e-9)
with wave.open('assets/score-original.wav','wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
ledger=[
 {'id':'paper-art','type':'image','files':['strength.png','strength-training.png','map.png','meal.png'],'source':'New die-cut paper illustrations generated in this task; original transparency retained. Human content limited to hands/forearm; no heads or facial features. Meal is an illustrative category icon, not a nutrient measurement.'},
 {'id':'identity','type':'image','files':['hero-logo.png','closing-logo.png','book-cover.svg','book-guide.svg','book-end.svg'],'source':'Owner-provided Mdaar mark and original front-cover SVG, copied unchanged.'},
 {'id':'font','type':'font','file':'Lalezar-Regular.ttf','source':'Google Fonts, SIL Open Font License; see FONT-LICENSE.txt.'},
 {'id':'score','type':'audio','file':'score.mp3','source':'Original deterministic synthesized music and paper-transition effects from create-score.py; no external music samples.','voiceover':False},
 {'id':'reference','type':'reference','source':'User-uploaded mdaar_protocol_ad_v3.mp4 used as editorial and visual reference only; file kept unchanged and not redistributed.'}
]
Path('media-provenance.jsonl').write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in ledger)+'\n')
print('Original 22.4-second score created; no external audio samples.')
