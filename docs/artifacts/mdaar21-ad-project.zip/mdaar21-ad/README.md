# إعلان مدار — رتّب رحلتك

إعلان عمودي عربي مدته 20 ثانية، 1080×1920، بأغلفة الكتاب ولقطات الموقع الفعلية. نصوص متحركة ومؤثرات انتقالية، بدون تعليق صوتي.

افتح المشروع في HyperFrames للتعديل. يحتاج Node.js 22+ وChromium وFFmpeg.

```sh
npx --yes hyperframes@0.8.189 preview --background
npx --yes hyperframes@0.8.189 check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.189 render --output renders/mdaar21-ad.mp4 --fps 24 --quality standard --workers 2
```

للمعاينة المحمولة شغّل خادم HTTP في هذا المجلد ثم افتح preview.html. الملف index.html هو التكوين القابل للتحرير، وليس مشغلاً مستقلاً.

DESIGN.md يوضح الهوية. SCRIPT.md للنص، وSTORYBOARD.md للمشاهد والتوقيت. review.json يسجل فحص مشغل الجوال.

أصول مدار والكتاب من ملفات المالك. الخطوط بترخيص OFL في FONT-LICENSE.txt. GSAP محفوظ محلياً مع ترويسة ترخيصه. مؤثر الانتقال من مكتبة HyperFrames المرفقة، موثق في media-provenance.jsonl.
