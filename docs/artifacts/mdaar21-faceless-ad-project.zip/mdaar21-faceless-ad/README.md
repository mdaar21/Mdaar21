# مدار — داخل تتمرّن ولا تقيّم ديكور النادي؟

موشن فوتوغرافي عمودي 30 ثانية. جميع الصور البشرية من أسفل عظام الترقوة، دون رؤوس أو ملامح أو انعكاسات لأشخاص. الصور مولدة لهذه المهمة؛ لا فيديو ممثلين أو مزامنة شفاه. الحوار مكتوب والموسيقى والمؤثرات أصلية. أدوات Magnific والتعليق الصوتي السعودي غير متاحة في الجلسة، ولم تُستخدم أو تُدَّعَ.

تكوين المصدر 1080×1920، تصدير 4K بمقاس 2160×3840 و24 إطارًا/ثانية، مع نسخة Full HD للمشاهدة السريعة. الصور الفوتوغرافية المصدرية أقل من دقة التصدير 4K؛ أبعاد الإخراج ليست ادعاء تصوير أصلي بكاميرا 4K.

```sh
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.189 preview --background
npm run check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.189 render --output renders/mdaar21-faceless-4k.mp4 --fps 24 --quality high --resolution portrait-4k --video-bitrate 8M --workers 3
```

`preview.html` مشغّل معاينة عند تقديم المجلد عبر HTTP، و`index.html` التكوين القابل للتحرير. DESIGN.md للهوية، SCRIPT.md للحوار، STORYBOARD.md للمشاهد، وmedia-provenance.jsonl لمصادر الأصول. الخطوط بترخيص OFL؛ الموسيقى تولد من create-soundtrack.py باستخدام NumPy وFFmpeg دون عينات خارجية.
