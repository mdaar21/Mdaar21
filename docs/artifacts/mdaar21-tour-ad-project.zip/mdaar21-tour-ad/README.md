# مدار — تمرين ولا جولة سياحية؟

إعلان موشن فوتوغرافي عمودي 30 ثانية، 1080×1920، بموقف كوميدي وحوار مكتوب. الصور لشخصيات خيالية أُنشئت لهذه النسخة، والأغلفة والواجهات من ملفات مدار الأصلية. الموسيقى والمؤثرات تركيب أصلي، دون تعليق صوتي أو مزامنة شفاه.

## المعاينة والتعديل

```sh
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.189 preview --background
npm run check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.8.189 render --output renders/mdaar21-tour-ad.mp4 --fps 24 --quality high --workers 3
```

`preview.html` مشغّل معاينة محمول عند تشغيل المجلد عبر HTTP. `index.html` التكوين القابل للتحرير. DESIGN.md للهوية وSCRIPT.md للحوار وSTORYBOARD.md للمشاهد. المصدر الصوتي في create-soundtrack.py، والخطوط بترخيص OFL، ومصدر الأصول في media-provenance.jsonl.

هذه نسخة إنتاج موشن وليست تصوير ممثلين بالفيديو. لا ضمان لأي قيمة بيع أو أداء تجاري.
